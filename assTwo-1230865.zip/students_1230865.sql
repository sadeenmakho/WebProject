USE web1230865_db;

DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  user_id CHAR(10) PRIMARY KEY,
  first_name VARCHAR(50) NOT NULL,
  last_name VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  mobile VARCHAR(30) NOT NULL,
  date_of_birth DATE NOT NULL,
  flat_no VARCHAR(30),
  street VARCHAR(100) NOT NULL,
  city VARCHAR(60) NOT NULL,
  country VARCHAR(60) NOT NULL,
  postal_code CHAR(6) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL
);

CREATE TABLE products (
  product_id INT AUTO_INCREMENT PRIMARY KEY,
  product_name VARCHAR(120) NOT NULL,
  category VARCHAR(80) NOT NULL,
  description TEXT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  quantity INT NOT NULL,
  rating DECIMAL(2,1) NOT NULL,
  photo1 VARCHAR(120) NOT NULL,
  photo2 VARCHAR(120) NOT NULL,
  photo3 VARCHAR(120) NOT NULL,
  default_photo VARCHAR(120) NOT NULL
);

CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id CHAR(10) NOT NULL UNIQUE,
  user_id CHAR(10) NOT NULL,
  order_date DATETIME NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE order_items (
  item_id INT AUTO_INCREMENT PRIMARY KEY,
  order_db_id INT NOT NULL,
  product_id INT NOT NULL,
  product_name VARCHAR(120) NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  quantity INT NOT NULL,
  line_total DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_db_id) REFERENCES orders(id),
  FOREIGN KEY (product_id) REFERENCES products(product_id)
);

INSERT INTO users (
  user_id,
  first_name,
  last_name,
  email,
  mobile,
  date_of_birth,
  flat_no,
  street,
  city,
  country,
  postal_code,
  password_hash,
  role
) VALUES
(
  '1000000001',
  'Lina',
  'Haddad',
  'customer1@example.com',
  '+970599111111',
  '1996-04-12',
  '2A',
  '18 Old Market Street',
  'Ramallah',
  'Palestine',
  '123456',
  '$2y$12$/0nmNntcyzvHRnrD6qOlOOAxbNOpx9UH.xc0jdY.f6TEWQuKtwGrO',
  'Customer'
),
(
  '1000000002',
  'Omar',
  'Nasser',
  'customer2@example.com',
  '+970599222222',
  '1992-08-22',
  '5B',
  '22 Olive Street',
  'Nablus',
  'Palestine',
  '654321',
  '$2y$12$eAnBl3DZhe9BY/MkGQv1lOIuCaFqpcTMOwYtZSMM2gI9BLRHCHWb.',
  'Customer'
),
(
  '9000000001',
  'Maya',
  'Khalil',
  'employee@example.com',
  '+970599333333',
  '1988-02-05',
  '1',
  '9 Ceramic Road',
  'Hebron',
  'Palestine',
  '112233',
  '$2y$12$DTQtCVDAEDZ0ItAkpyUdH.m0hGwRKAOInlrzp9/ZpsPG7d21tISMC',
  'Employee'
);

INSERT INTO products (
  product_name,
  category,
  description,
  price,
  quantity,
  rating,
  photo1,
  photo2,
  photo3,
  default_photo
) VALUES
(
  'Hebron Ceramic Coffee Cups',
  'Handcrafted Ceramics',
  'A colorful coffee cup set inspired by traditional Hebron ceramic workshops. The cups are useful for Arabic coffee, tea, display shelves, and cultural gifts.',
  38.00,
  25,
  4.8,
  'ceramic-cup.png',
  'home-hero.png',
  'olive-soap.png',
  'ceramic-cup.png'
),
(
  'Nablus Olive Oil Soap Gift Box',
  'Natural Olive-Oil Products',
  'A natural olive-oil soap gift box inspired by the soap-making history of Nablus. It is simple, useful, and connected to Palestinian olive trees.',
  26.00,
  40,
  4.7,
  'olive-soap.png',
  'home-hero.png',
  'ceramic-cup.png',
  'olive-soap.png'
),
(
  'Tatreez Embroidery Wall Hanging',
  'Traditional Embroidery',
  'A decorative wall hanging with red geometric embroidery patterns inspired by Palestinian tatreez and village textile traditions.',
  45.00,
  18,
  4.9,
  'home-hero.png',
  'ceramic-cup.png',
  'olive-soap.png',
  'home-hero.png'
),
(
  'Olive Wood Keychains Set',
  'Olive Wood Gifts',
  'A small set of olive wood keychains made for lightweight cultural souvenirs. The design is inspired by Palestinian olive groves.',
  18.50,
  60,
  4.4,
  'olive-soap.png',
  'ceramic-cup.png',
  'home-hero.png',
  'olive-soap.png'
),
(
  'Palestinian Keffiyeh Scarf',
  'Textile Gifts',
  'A black and white scarf inspired by the Palestinian keffiyeh pattern. It can be worn daily or kept as a meaningful souvenir.',
  32.00,
  35,
  4.6,
  'home-hero.png',
  'olive-soap.png',
  'ceramic-cup.png',
  'ceramic-cup.png'
),
(
  'Dead Sea Salt Pouch',
  'Natural Gifts',
  'A small pouch of mineral salt inspired by the Dead Sea area. It is suitable as a natural care gift and travel souvenir.',
  14.00,
  50,
  4.2,
  'olive-soap.png',
  'home-hero.png',
  'ceramic-cup.png',
  'olive-soap.png'
),
(
  'Ceramic Evil Eye Plate',
  'Handcrafted Ceramics',
  'A decorative ceramic plate with blue eye and floral motifs. The design is inspired by regional handmade ceramic art.',
  29.00,
  20,
  4.5,
  'ceramic-cup.png',
  'home-hero.png',
  'olive-soap.png',
  'ceramic-cup.png'
),
(
  'Date Maamoul Gift Tin',
  'Food Gifts',
  'A gift tin inspired by Palestinian maamoul cookies filled with dates. It is presented as a friendly food souvenir.',
  22.00,
  30,
  4.3,
  'home-hero.png',
  'olive-soap.png',
  'ceramic-cup.png',
  'home-hero.png'
),
(
  'Bethlehem Star Ornament',
  'Home Decor',
  'A small home ornament inspired by the Bethlehem star. It is suitable for shelves, desks, and cultural holiday gifts.',
  16.00,
  45,
  4.1,
  'home-hero.png',
  'ceramic-cup.png',
  'olive-soap.png',
  'olive-soap.png'
),
(
  'Embroidered Tote Bag',
  'Textile Gifts',
  'A practical tote bag decorated with embroidery-style motifs. It combines daily use with Palestinian cultural identity.',
  35.00,
  22,
  4.6,
  'home-hero.png',
  'olive-soap.png',
  'ceramic-cup.png',
  'home-hero.png'
);