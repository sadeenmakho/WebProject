<?php
require_once 'functions.inc.php';
require_once 'dbconfig.inc.php';
require_once 'Product.class.php';

start_session_once();

function default_product_state() {
    return array(
        'name' => '',
        'max_price' => '',
        'category' => '',
        'sort_col' => 'product_id',
        'sort_dir' => 'ASC',
        'current_page' => 1,
        'per_page' => 5
    );
}

function clean_product_state($state) {
    $default = default_product_state();

    foreach ($default as $key => $value) {
        if (!isset($state[$key])) {
            $state[$key] = $value;
        }
    }

    $state['name'] = trim((string)$state['name']);
    $state['max_price'] = trim((string)$state['max_price']);
    $state['category'] = trim((string)$state['category']);

    if ($state['max_price'] != '' && !is_numeric($state['max_price'])) {
        $state['max_price'] = '';
    }

    if ($state['sort_col'] != 'product_id' && $state['sort_col'] != 'price' && $state['sort_col'] != 'category') {
        $state['sort_col'] = 'product_id';
    }

    if ($state['sort_dir'] != 'ASC' && $state['sort_dir'] != 'DESC') {
        $state['sort_dir'] = 'ASC';
    }

    $state['current_page'] = (int)$state['current_page'];

    if ($state['current_page'] < 1) {
        $state['current_page'] = 1;
    }

    $state['per_page'] = (int)$state['per_page'];

    if ($state['per_page'] != 5 && $state['per_page'] != 10 && $state['per_page'] != 15 && $state['per_page'] != 20 && $state['per_page'] != 0) {
        $state['per_page'] = 5;
    }

    return $state;
}

function save_product_state($state) {
    $_SESSION['product_search_state'] = json_encode($state);
}

function load_product_state() {
    $state = default_product_state();

    if (isset($_SESSION['product_search_state']) && $_SESSION['product_search_state'] != '') {
        $decoded = json_decode($_SESSION['product_search_state'], true);

        if (is_array($decoded)) {
            $state = $decoded;
        }
    }

    return clean_product_state($state);
}

function products_url($state, $changes) {
    foreach ($changes as $key => $value) {
        $state[$key] = $value;
    }

    $params = array(
        'name' => $state['name'],
        'max_price' => $state['max_price'],
        'category' => $state['category'],
        'sort_col' => $state['sort_col'],
        'sort_dir' => $state['sort_dir'],
        'page' => $state['current_page'],
        'per_page' => $state['per_page']
    );

    return 'products.php?' . http_build_query($params);
}

function sort_header_link($column, $label, $state) {
    $direction = 'ASC';

    if ($state['sort_col'] == $column && $state['sort_dir'] == 'ASC') {
        $direction = 'DESC';
    }

    $url = products_url($state, array('sort_col' => $column, 'sort_dir' => $direction, 'current_page' => 1));

    return '<a href="' . e($url) . '">' . e($label) . '</a>';
}

function bind_search_values($stmt, $state) {
    $stmt->bindValue(':name_empty', $state['name']);
    $stmt->bindValue(':name_like', '%' . $state['name'] . '%');
    $stmt->bindValue(':max_price_empty', $state['max_price']);

    if ($state['max_price'] == '') {
        $stmt->bindValue(':max_price', 0);
    } else {
        $stmt->bindValue(':max_price', $state['max_price']);
    }

    $stmt->bindValue(':category_empty', $state['category']);
    $stmt->bindValue(':category_value', $state['category']);
}

if (isset($_GET['reset'])) {
    unset($_SESSION['product_search_state']);
    redirect_to('products.php');
}

$state = load_product_state();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $state['name'] = post_value('name');
    $state['max_price'] = post_value('max_price');
    $state['category'] = post_value('category');
    $state['per_page'] = (int)post_value('per_page');
    $state['current_page'] = 1;

    $state = clean_product_state($state);
    save_product_state($state);
} elseif (count($_GET) > 0) {
    if (isset($_GET['name'])) { $state['name'] = get_value('name'); }
    if (isset($_GET['max_price'])) { $state['max_price'] = get_value('max_price'); }
    if (isset($_GET['category'])) { $state['category'] = get_value('category'); }
    if (isset($_GET['sort_col'])) { $state['sort_col'] = get_value('sort_col'); }
    if (isset($_GET['sort_dir'])) { $state['sort_dir'] = get_value('sort_dir'); }
    if (isset($_GET['page'])) { $state['current_page'] = (int)get_value('page'); }
    if (isset($_GET['per_page'])) { $state['per_page'] = (int)get_value('per_page'); }

    $state = clean_product_state($state);
    save_product_state($state);
}

$categoryStmt = $pdo->prepare('SELECT DISTINCT category FROM products ORDER BY category ASC');
$categoryStmt->execute();
$categories = $categoryStmt->fetchAll();

$whereSql = ' FROM products WHERE (:name_empty = \'\' OR LOWER(product_name) LIKE LOWER(:name_like)) AND (:max_price_empty = \'\' OR price <= :max_price) AND (:category_empty = \'\' OR category = :category_value)';

$countStmt = $pdo->prepare('SELECT COUNT(*) AS total' . $whereSql);
bind_search_values($countStmt, $state);
$countStmt->execute();
$totalRowsData = $countStmt->fetch();
$totalRows = (int)$totalRowsData['total'];

if ($state['per_page'] == 0) {
    $totalPages = 1;
    $state['current_page'] = 1;
    $limitRows = $totalRows > 0 ? $totalRows : 1;
    $offsetRows = 0;
} else {
    $totalPages = (int)ceil($totalRows / $state['per_page']);

    if ($totalPages < 1) {
        $totalPages = 1;
    }

    if ($state['current_page'] > $totalPages) {
        $state['current_page'] = $totalPages;
    }

    $limitRows = $state['per_page'];
    $offsetRows = ($state['current_page'] - 1) * $state['per_page'];
}

save_product_state($state);

$productSql = 'SELECT product_id AS productId, product_name AS productName, category AS category, description AS description, price AS price, quantity AS quantity, rating AS rating, photo1 AS photo1, photo2 AS photo2, photo3 AS photo3, default_photo AS defaultPhoto' . $whereSql . ' ORDER BY CASE WHEN :sort_col_1 = \'product_id\' AND :sort_dir_1 = \'ASC\' THEN product_id END ASC, CASE WHEN :sort_col_2 = \'product_id\' AND :sort_dir_2 = \'DESC\' THEN product_id END DESC, CASE WHEN :sort_col_3 = \'price\' AND :sort_dir_3 = \'ASC\' THEN price END ASC, CASE WHEN :sort_col_4 = \'price\' AND :sort_dir_4 = \'DESC\' THEN price END DESC, CASE WHEN :sort_col_5 = \'category\' AND :sort_dir_5 = \'ASC\' THEN category END ASC, CASE WHEN :sort_col_6 = \'category\' AND :sort_dir_6 = \'DESC\' THEN category END DESC, product_id ASC LIMIT :limit_rows OFFSET :offset_rows';

$productStmt = $pdo->prepare($productSql);

bind_search_values($productStmt, $state);

$productStmt->bindValue(':sort_col_1', $state['sort_col']);
$productStmt->bindValue(':sort_dir_1', $state['sort_dir']);
$productStmt->bindValue(':sort_col_2', $state['sort_col']);
$productStmt->bindValue(':sort_dir_2', $state['sort_dir']);
$productStmt->bindValue(':sort_col_3', $state['sort_col']);
$productStmt->bindValue(':sort_dir_3', $state['sort_dir']);
$productStmt->bindValue(':sort_col_4', $state['sort_col']);
$productStmt->bindValue(':sort_dir_4', $state['sort_dir']);
$productStmt->bindValue(':sort_col_5', $state['sort_col']);
$productStmt->bindValue(':sort_dir_5', $state['sort_dir']);
$productStmt->bindValue(':sort_col_6', $state['sort_col']);
$productStmt->bindValue(':sort_dir_6', $state['sort_dir']);
$productStmt->bindValue(':limit_rows', $limitRows, PDO::PARAM_INT);
$productStmt->bindValue(':offset_rows', $offsetRows, PDO::PARAM_INT);

$productStmt->execute();

prepare_layout('Products');

require_once 'header.inc.php';
?>

  <main>
    <section>
      <h2>Products</h2>

      <?php if (is_employee()) { ?>
      <p><a href="add.php">Add Product</a></p>
      <?php } ?>
    </section>

    <section>
      <h2>Advanced Product Search</h2>

      <form action="products.php" method="post">
        <fieldset>
          <legend>Search Filters</legend>

          <p>
            <label for="name">Product Name</label><br>
            <input type="text" id="name" name="name" placeholder="Product Name" value="<?php echo e($state['name']); ?>">
          </p>

          <p>
            <label for="max_price">Maximum Price</label><br>
            <input type="number" step="0.01" id="max_price" name="max_price" placeholder="Max Price" value="<?php echo e($state['max_price']); ?>">
          </p>

          <p>
            <label for="category">Category</label><br>
            <select id="category" name="category">
              <option value="">Select Category</option>

              <?php foreach ($categories as $cat) { ?>
              <option value="<?php echo e($cat['category']); ?>"<?php echo selected_if($cat['category'], $state['category']); ?>><?php echo e($cat['category']); ?></option>
              <?php } ?>
            </select>
          </p>

          <p>
            <label for="per_page">Records Per Page</label><br>
            <select id="per_page" name="per_page">
              <option value="5"<?php echo selected_if(5, $state['per_page']); ?>>5</option>
              <option value="10"<?php echo selected_if(10, $state['per_page']); ?>>10</option>
              <option value="15"<?php echo selected_if(15, $state['per_page']); ?>>15</option>
              <option value="20"<?php echo selected_if(20, $state['per_page']); ?>>20</option>
              <option value="0"<?php echo selected_if(0, $state['per_page']); ?>>All</option>
            </select>
          </p>

          <p>
            <button type="submit">Filter</button>
            <a href="products.php?reset=1">Reset / Show All</a>
          </p>
        </fieldset>
      </form>
    </section>

    <section>
      <h2>Products Table Result</h2>

      <p>Page <?php echo e($state['current_page']); ?> of <?php echo e($totalPages); ?></p>

      <table>
        <caption>Product search result</caption>

        <thead>
          <tr>
            <th scope="col">Product Image</th>
            <th scope="col"><?php echo sort_header_link('product_id', 'Product ID', $state); ?></th>
            <th scope="col">Product Name</th>
            <th scope="col"><?php echo sort_header_link('category', 'Category', $state); ?></th>
            <th scope="col"><?php echo sort_header_link('price', 'Price', $state); ?></th>
            <th scope="col">Quantity</th>
            <th scope="col">Actions</th>
          </tr>
        </thead>

        <tbody>
          <?php
          if ($totalRows == 0) {
              echo '<tr><td colspan="7">No products found.</td></tr>';
          } else {
              while ($product = $productStmt->fetchObject('Product')) {
                  echo $product->displayInTable();
              }
          }
          ?>
        </tbody>
      </table>

      <nav aria-label="Pagination">
        <p>
          <?php
          if ($state['current_page'] > 1 && $state['per_page'] != 0) {
              echo '<a href="' . e(products_url($state, array('current_page' => $state['current_page'] - 1))) . '">Previous</a> ';
          }

          if ($state['current_page'] < $totalPages && $state['per_page'] != 0) {
              echo '<a href="' . e(products_url($state, array('current_page' => $state['current_page'] + 1))) . '">Next</a>';
          }
          ?>
        </p>
      </nav>
    </section>
  </main>

<?php
require_once 'footer.inc.php';
?>