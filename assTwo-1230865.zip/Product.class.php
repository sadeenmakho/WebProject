<?php
class Product {
    private $productId;
    private $productName;
    private $category;
    private $description;
    private $price;
    private $quantity;
    private $rating;
    private $photo1;
    private $photo2;
    private $photo3;
    private $defaultPhoto;

    public function __construct(
        $productId = null,
        $productName = null,
        $category = null,
        $description = null,
        $price = null,
        $quantity = null,
        $rating = null,
        $photo1 = null,
        $photo2 = null,
        $photo3 = null,
        $defaultPhoto = null
    ) {
        if (func_num_args() > 0) {
            $this->productId = $productId;
            $this->productName = $productName;
            $this->category = $category;
            $this->description = $description;
            $this->price = $price;
            $this->quantity = $quantity;
            $this->rating = $rating;
            $this->photo1 = $photo1;
            $this->photo2 = $photo2;
            $this->photo3 = $photo3;
            $this->defaultPhoto = $defaultPhoto;
        }
    }

    public function __set($name, $value) {
        if ($name == 'productId') { $this->productId = $value; }
        if ($name == 'productName') { $this->productName = $value; }
        if ($name == 'category') { $this->category = $value; }
        if ($name == 'description') { $this->description = $value; }
        if ($name == 'price') { $this->price = $value; }
        if ($name == 'quantity') { $this->quantity = $value; }
        if ($name == 'rating') { $this->rating = $value; }
        if ($name == 'photo1') { $this->photo1 = $value; }
        if ($name == 'photo2') { $this->photo2 = $value; }
        if ($name == 'photo3') { $this->photo3 = $value; }
        if ($name == 'defaultPhoto') { $this->defaultPhoto = $value; }
    }

    private function h($value) {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }

    private function imagePath($photo) {
        $photo = trim((string)$photo);

        if ($photo == '') {
            $photo = 'home-hero.png';
        }

        return './images/' . $this->h($photo);
    }

    public function getProductId() { return $this->productId; }
    public function setProductId($productId) { $this->productId = $productId; }

    public function getProductName() { return $this->productName; }
    public function setProductName($productName) { $this->productName = $productName; }

    public function getCategory() { return $this->category; }
    public function setCategory($category) { $this->category = $category; }

    public function getDescription() { return $this->description; }
    public function setDescription($description) { $this->description = $description; }

    public function getPrice() { return $this->price; }
    public function setPrice($price) { $this->price = $price; }

    public function getQuantity() { return $this->quantity; }
    public function setQuantity($quantity) { $this->quantity = $quantity; }

    public function getRating() { return $this->rating; }
    public function setRating($rating) { $this->rating = $rating; }

    public function getPhoto1() { return $this->photo1; }
    public function setPhoto1($photo1) { $this->photo1 = $photo1; }

    public function getPhoto2() { return $this->photo2; }
    public function setPhoto2($photo2) { $this->photo2 = $photo2; }

    public function getPhoto3() { return $this->photo3; }
    public function setPhoto3($photo3) { $this->photo3 = $photo3; }

    public function getDefaultPhoto() { return $this->defaultPhoto; }
    public function setDefaultPhoto($defaultPhoto) { $this->defaultPhoto = $defaultPhoto; }

    public function displayInTable() {
    $id = $this->h($this->productId);
    $name = $this->h($this->productName);
    $category = $this->h($this->category);
    $price = number_format((float)$this->price, 2);
    $quantity = $this->h($this->quantity);
    $defaultPhotoPath = $this->imagePath($this->defaultPhoto);

    $html = '<tr>';

    $html .= '<td>';
    $html .= '<img src="' . $defaultPhotoPath . '" alt="' . $name . '" width="120" height="90">';
    $html .= '</td>';

    $html .= '<td>';
    $html .= '<a href="view.php?id=' . $id . '">' . $id . '</a>';
    $html .= '</td>';

    $html .= '<td>' . $name . '</td>';
    $html .= '<td>' . $category . '</td>';
    $html .= '<td>' . $price . '</td>';
    $html .= '<td>' . $quantity . '</td>';

    $html .= '<td>';
    $html .= '<a href="view.php?id=' . $id . '">View</a>';

    $role = '';

    if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true && isset($_SESSION['role'])) {
        $role = $_SESSION['role'];
    }

    if ($role == 'Employee') {
        $html .= ' <a href="edit.php?id=' . $id . '">Edit</a>';
    } else {
        $html .= ' <a href="add_to_basket.php?id=' . $id . '">Add to Basket</a>';
    }

    $html .= '</td>';
    $html .= '</tr>';

    return $html;
}

    public function displayProductPage() {
        $isEmployee = false;

        if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true && isset($_SESSION['role']) && $_SESSION['role'] == 'Employee') {
            $isEmployee = true;
        }

        $id = $this->h($this->productId);
        $name = $this->h($this->productName);
        $category = $this->h($this->category);
        $description = $this->h($this->description);
        $price = $this->h($this->price);
        $quantity = $this->h($this->quantity);
        $rating = $this->h($this->rating);
        $defaultPhotoPath = $this->imagePath($this->defaultPhoto);

        $editableDisabled = $isEmployee ? '' : ' disabled';
       
        $photoDisabled = $isEmployee ? '' : ' disabled';
        
        $defaultPhotoClean = trim((string)$this->defaultPhoto);
        $photo1Clean = trim((string)$this->photo1);
        $photo2Clean = trim((string)$this->photo2);
        $photo3Clean = trim((string)$this->photo3);

        $checked1 = ($defaultPhotoClean == $photo1Clean) ? ' checked' : '';
        $checked2 = ($defaultPhotoClean == $photo2Clean) ? ' checked' : '';
        $checked3 = ($defaultPhotoClean == $photo3Clean) ? ' checked' : '';

if ($checked1 == '' && $checked2 == '' && $checked3 == '') {
    $checked1 = ' checked';
}

        $html = '<main>';
        $html .= '<article>';
        $html .= '<h2>Product Detail Page</h2>';

        $html .= '<figure>';
        $html .= '<img src="' . $defaultPhotoPath . '" alt="' . $name . '" width="520" height="340" onerror="this.src=\'./images/home-hero.png\'">';
        $html .= '<figcaption>' . $name . '</figcaption>';
        $html .= '</figure>';

        $html .= '<form action="edit.php" method="post">';
        $html .= '<fieldset>';
        $html .= '<legend>Product Information</legend>';

        $html .= '<input type="hidden" name="product_id" value="' . $id . '">';

        $html .= '<p><label for="product_id_display">Product ID</label><br>';
        $html .= '<input type="text" id="product_id_display" value="' . $id . '" disabled></p>';

        $html .= '<p><label for="product_name_display">Product Name</label><br>';
        $html .= '<input type="text" id="product_name_display" value="' . $name . '" disabled></p>';

        $html .= '<p><label for="category_display">Category</label><br>';
        $html .= '<select id="category_display" name="category" disabled>';
        $html .= '<option selected>' . $category . '</option>';
        $html .= '</select></p>';

        $html .= '<p><label for="description">Description</label><br>';
        $html .= '<textarea id="description" name="description" rows="6" cols="60"' . $editableDisabled . '>' . $description . '</textarea></p>';

        $html .= '<p><label for="price">Price</label><br>';
        $html .= '<input type="number" step="0.01" id="price" name="price" value="' . $price . '"' . $editableDisabled . '></p>';

        $html .= '<p><label for="quantity">Quantity</label><br>';
        $html .= '<input type="number" id="quantity" name="quantity" value="' . $quantity . '"' . $editableDisabled . '></p>';

        $html .= '<p><label for="rating_display">Rating</label><br>';
        $html .= '<input type="text" id="rating_display" value="' . $rating . '" disabled></p>';

        $html .= '<fieldset>';
        $html .= '<legend>Photos</legend>';
        $html .= '<p><label><input type="radio" name="default_photo" value="1"' . $checked1 . $photoDisabled . '> Photo 1</label></p>';
        $html .= '<p><label><input type="radio" name="default_photo" value="2"' . $checked2 . $photoDisabled . '> Photo 2</label></p>';
        $html .= '<p><label><input type="radio" name="default_photo" value="3"' . $checked3 . $photoDisabled . '> Photo 3</label></p>';
        $html .= '</fieldset>';

        if ($isEmployee) {
            $html .= '<p><button type="submit">Save Changes</button></p>';
        }

        $html .= '</fieldset>';
        $html .= '</form>';

        $html .= '<nav aria-label="Product actions">';
        $html .= '<p><a href="products.php">Back to Products</a></p>';

        if (!$isEmployee) {
            $html .= '<p><a href="add_to_basket.php?id=' . $id . '">Add to Basket</a></p>';
        }

        $html .= '</nav>';
        $html .= '</article>';
        $html .= '</main>';

        return $html;
    }
}
?>