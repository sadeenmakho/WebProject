<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo e($page_title); ?> - Palestine Imprint Souvenirs</title>
</head>
<body>
  <header>
    <img src="./images/logo.png" alt="Palestine Imprint Souvenirs logo" width="120" height="120">
  <h1>Palestine Imprint Souvenirs</h1>
    <p>Authentic Palestinian gifts carrying the imprint of heritage.</p>

    <nav aria-label="Main navigation">
      <ul>
        <li><a href="index.php">Assignment 2 Home</a></li>
        <li><a href="products.php">Products</a></li>
        <?php echo $header_auth_links; ?>
        <li><a href="basket.php">Basket</a></li>
        <li><a href="contact.php">Contact Us</a></li>
      </ul>
    </nav>

    <?php echo $header_user_info; ?>
  </header>