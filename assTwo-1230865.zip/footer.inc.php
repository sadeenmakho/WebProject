  <footer>
    <address>
      Palestine Imprint Souvenirs<br>
      18 Old Market Street<br>
      Ramallah, Palestine<br>
      Telephone: <a href="tel:+97022990000">+970 2 299 0000</a><br>
      Email: <a href="mailto:support@palestineimprint.example">support@palestineimprint.example</a>
    </address>

    <p>Customer support: <a href="contact.php">Contact Us</a></p>
  </footer>
</body>
</html>