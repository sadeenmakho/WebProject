<?php
require_once 'functions.inc.php';

start_session_once();
prepare_layout('Shopping Basket');

require_once 'header.inc.php';
?>

  <main>
    <section>
      <h2>Shopping Basket</h2>

      <?php if (!isset($_SESSION['basket']) || count($_SESSION['basket']) == 0) { ?>

      <p>Your shopping basket is empty.</p>
      <p><a href="products.php">Back to Products</a></p>

      <?php } else { ?>

      <table>
        <caption>Current basket contents</caption>

        <thead>
          <tr>
            <th scope="col">Product Image</th>
            <th scope="col">Product Name</th>
            <th scope="col">Unit Price</th>
            <th scope="col">Quantity</th>
            <th scope="col">Line Total</th>
            <th scope="col">Remove</th>
          </tr>
        </thead>

        <tbody>
          <?php
          foreach ($_SESSION['basket'] as $productId => $item) {
              $lineTotal = ((float)$item['unit_price']) * ((int)$item['quantity']);

              echo '<tr>';
              echo '<td><img src="images/' . e($item['default_photo']) . '" alt="' . e($item['product_name']) . '" width="100" height="70"></td>';
              echo '<td>' . e($item['product_name']) . '</td>';
              echo '<td>' . e(number_format((float)$item['unit_price'], 2)) . '</td>';
              echo '<td>' . e($item['quantity']) . '</td>';
              echo '<td>' . e(number_format($lineTotal, 2)) . '</td>';
              echo '<td><a href="remove_from_basket.php?id=' . e($productId) . '">Remove</a></td>';
              echo '</tr>';
          }
          ?>
        </tbody>
      </table>

      <p>Basket Total: <strong><?php echo e(number_format(basket_total(), 2)); ?></strong></p>
      <p><a href="products.php">Continue Shopping</a></p>
      <p><a href="checkout.php">Proceed to Checkout</a></p>

      <?php } ?>
    </section>
  </main>

<?php
require_once 'footer.inc.php';
?>